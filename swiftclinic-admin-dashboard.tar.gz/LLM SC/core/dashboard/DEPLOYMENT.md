# Deployment Guide - SwiftClinic Admin Dashboard

This guide will help you deploy your admin dashboard to `www.swiftclinic.ai/admin` with Firebase as the backend database.

## Prerequisites

- Firebase project set up
- Custom domain `www.swiftclinic.ai` configured
- Firebase Admin SDK service account JSON file
- Node.js 18+ and npm

## 🔥 Firebase Setup

### 1. Create Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create new project or use existing one
3. Enable Firestore Database
4. Set Firestore rules to allow authenticated access:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Allow read/write for admin dashboard
    match /{document=**} {
      allow read, write: if true; // Secure this based on your auth requirements
    }
  }
}
```

### 2. Generate Service Account

1. Go to Project Settings > Service accounts
2. Click "Generate new private key"
3. Save the JSON file as `firebase-service-account.json` in `LLM SC/core/dashboard/`
4. Update the file with your actual Firebase project details

### 3. Configure Firebase Collections

The dashboard uses these Firestore collections:
- `clinics` - Clinic configurations
- `webhooks` - Webhook endpoints
- `knowledge_documents` - Knowledge base files
- `analytics` - Analytics data
- `health` - Health check data

## 🌐 Domain Configuration

### 1. Backend Deployment (Express API)

**Option A: VPS/Cloud Server**
```bash
# On your server
cd LLM SC/core/dashboard/backend
npm install
npm run build
npm start
```

**Option B: Platform as a Service (Heroku, Railway, etc.)**
1. Deploy the `backend/` folder
2. Set environment variables (see below)
3. Ensure the service runs on the configured port

### 2. Frontend Deployment (React App)

**Option A: Static Hosting (Netlify, Vercel)**
```bash
cd LLM SC/core/dashboard/frontend
npm install
npm run build
# Deploy the dist/ folder to your static hosting
```

**Option B: Custom Server**
```bash
cd LLM SC/core/dashboard/frontend
npm install
npm run build
# Serve dist/ folder with nginx or Apache at /admin path
```

### 3. Web Server Configuration

**Nginx Configuration Example:**
```nginx
server {
    listen 80;
    server_name www.swiftclinic.ai swiftclinic.ai;
    
    # Redirect to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl;
    server_name www.swiftclinic.ai;
    
    ssl_certificate /path/to/certificate.crt;
    ssl_certificate_key /path/to/private.key;
    
    # Admin dashboard frontend
    location /admin {
        alias /path/to/dashboard/frontend/dist;
        try_files $uri $uri/ /admin/index.html;
        
        # Security headers
        add_header X-Frame-Options DENY;
        add_header X-Content-Type-Options nosniff;
        add_header X-XSS-Protection "1; mode=block";
    }
    
    # Admin dashboard API
    location /api {
        proxy_pass http://localhost:3001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Your main website
    location / {
        # Your main website configuration
        root /path/to/main/website;
        index index.html;
    }
}
```

## 📝 Environment Variables

### Backend (.env in project root)
```bash
# Firebase Configuration
FIREBASE_SERVICE_ACCOUNT_PATH=/path/to/firebase-service-account.json

# Server Configuration
PORT=3001
NODE_ENV=production
BASE_URL=https://www.swiftclinic.ai

# Security
MASTER_PASSWORD=your-very-secure-master-password-here
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100

# CORS
ALLOWED_ORIGINS=https://www.swiftclinic.ai,https://swiftclinic.ai
```

### Frontend (.env in frontend folder)
```bash
# API Configuration
VITE_API_BASE_URL=https://www.swiftclinic.ai/api

# Authentication
VITE_ADMIN_PASSWORD=admin123

# App Configuration
VITE_APP_NAME=SwiftClinic Admin
VITE_APP_VERSION=1.0.0
```

## 🚀 Deployment Steps

### 1. Install Dependencies
```bash
# Backend
cd LLM SC/core/dashboard/backend
npm install

# Frontend
cd ../frontend
npm install
```

### 2. Configure Firebase
```bash
# Copy template and edit with your details
cp firebase-service-account.json.template firebase-service-account.json
# Edit firebase-service-account.json with your Firebase project details
```

### 3. Build Frontend
```bash
cd LLM SC/core/dashboard/frontend
npm run build
```

### 4. Deploy Backend
```bash
cd ../backend
npm run build
npm start
```

### 5. Configure Web Server
- Set up nginx/Apache configuration
- Configure SSL certificates
- Set up reverse proxy for API routes

### 6. Test Deployment
1. Visit `https://www.swiftclinic.ai/admin`
2. Login with your admin credentials
3. Test clinic creation and management
4. Verify Firebase data persistence

## 🔧 Maintenance

### Updating the Dashboard
```bash
# Pull latest changes
git pull origin main

# Update dependencies
cd LLM SC/core/dashboard/backend && npm install
cd ../frontend && npm install

# Rebuild and redeploy
cd ../frontend && npm run build
cd ../backend && npm run build && pm2 restart dashboard-backend
```

### Monitoring
- Monitor Firebase usage in Firebase Console
- Check server logs for backend issues
- Set up uptime monitoring for the dashboard

### Backup
- Firebase automatically backs up your data
- Consider exporting clinic configurations periodically
- Keep environment variables secure and backed up

## 🔒 Security Considerations

1. **Environment Variables**: Never commit sensitive data to git
2. **Firebase Rules**: Implement proper Firestore security rules
3. **SSL**: Always use HTTPS in production
4. **Rate Limiting**: Configure appropriate rate limits
5. **Admin Access**: Use strong passwords and consider 2FA

## 📞 Support

If you encounter issues:
1. Check the logs in both frontend and backend
2. Verify Firebase connectivity
3. Ensure all environment variables are set correctly
4. Test the API endpoints directly

---

**Your dashboard will be available at: https://www.swiftclinic.ai/admin** 